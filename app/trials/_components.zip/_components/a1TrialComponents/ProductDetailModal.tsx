"use client";

import { useId } from "react";
import type { ReactNode } from "react";
import { useRouter } from "next/navigation";
import { trackAction } from "@/app/actions/track";
import { getClientLogBase } from "@/lib/log/clientLogBase";

type ProductForDetailModal = {
  id: string;
  name: string;
  priceYen: number;
  description: string;
  specsAndNotes: string[];
  prePurchaseCheck: string[];
  deliveryInfo: string[];
  dpDisplay?: { label: string } | null;
  imageSrc: string;
};

type ProductDetailModalProps = {
  product: ProductForDetailModal;
  set: string;
  trial: string;
  nextPath: string;
  dpArea?: ReactNode;
};

function yen(n: number) {
  return new Intl.NumberFormat("ja-JP").format(n);
}

export function ProductDetailModal({
  product,
  set,
  trial,
  nextPath,
  dpArea,
}: ProductDetailModalProps) {
  const dialogId = useId();
  const router = useRouter();

  const showViewer = Boolean(dpArea || product.dpDisplay);
  const viewerText = product.dpDisplay?.label;

  function createBaseLog() {
    const logParams = new URLSearchParams();
    logParams.set("set", set);
    logParams.set("trial", trial);

    return getClientLogBase({ searchParams: logParams });
  }

  return (
    <>
      <button
        type="button"
        className="flex items-center justify-center border border-gray-300 rounded-md text-[18px] font-bold text-black"
        onClick={() => {
          const baseLog = createBaseLog();

          void trackAction({
            ...baseLog,
            phase: "main",
            page: "product",
            type: "view_detail",
            meta: {},
            payload: { productId: product.id },
          });

          const el = document.getElementById(
            dialogId,
          ) as HTMLDialogElement | null;
          el?.showModal();
        }}
      >
        詳細を見る
      </button>

      <dialog
        id={dialogId}
        className="fixed left-[470px] top-[110px] h-[860px] w-[980px] overflow-hidden rounded-md p-0 backdrop:bg-black/70"
      >
        <div className="h-full w-full overflow-hidden bg-white">
          <div className="flex h-[70px] items-center justify-between border-b border-gray-300 px-[60px]">
            <h2 className="text-[28px] font-bold text-gray-900">商品詳細</h2>

            <button
              type="button"
              className="h-[40px] w-[100px] border border-gray-300 bg-white text-[17px] font-bold text-gray-700"
              onClick={() => {
                const baseLog = createBaseLog();

                void trackAction({
                  ...baseLog,
                  phase: "main",
                  page: "product",
                  type: "close_detail",
                  meta: {},
                  payload: { productId: product.id },
                });

                const el = document.getElementById(
                  dialogId,
                ) as HTMLDialogElement | null;
                el?.close();
              }}
            >
              閉じる
            </button>
          </div>

          <div className="flex h-[790px] overflow-hidden px-[60px]">
            <div className="flex w-[400px] flex-col">
              <div className="h-[60px]" />

              <div className="flex h-[120px] w-full items-center justify-center bg-gray-50">
                <img
                  src={product.imageSrc}
                  alt=""
                  className="max-h-[80px] max-w-[110px] object-contain"
                />
              </div>

              <div className="h-[60px]" />

              <section className="h-[160px] overflow-hidden border border-gray-300 p-[16px]">
                <h3 className="mb-[12px] text-[18px] font-bold text-gray-900">
                  商品説明
                </h3>
                <div className="text-[15px] font-medium leading-[23px] text-gray-600">
                  <p>{product.description}</p>
                </div>
              </section>

              <div className="h-[60px]" />

              <section className="h-[160px] overflow-hidden border border-gray-300 p-[16px]">
                <h3 className="mb-[12px] text-[18px] font-bold text-gray-900">
                  仕様・補足
                </h3>
                <div className="text-[15px] font-medium leading-[23px] text-gray-600">
                  {product.specsAndNotes.map((line) => (
                    <div key={line}>{line}</div>
                  ))}
                </div>
              </section>
            </div>

            <div className="w-[60px]" />

            <div className="flex w-[400px] flex-col">
              <div className="h-[60px]" />

              <div className="h-[35px]">
                {showViewer ? (
                  dpArea ? (
                    dpArea
                  ) : (
                    <div className="flex h-full items-center justify-center  px-3 text-[16px] font-semibold leading-[35px] text-orange-700">
                      <p className="truncate">{viewerText}</p>
                    </div>
                  )
                ) : (
                  <div className="h-full w-full" aria-hidden="true" />
                )}
              </div>

              <div className="h-[60px]" />

              <h3 className="h-[35px] overflow-hidden text-[22px] font-bold leading-[35px] text-gray-900">
                {product.name}
              </h3>

              <div className="h-[60px]" />

              <p className="h-[35px] text-[26px] font-bold leading-[35px] text-gray-900">
                ¥{yen(product.priceYen)}
              </p>

              <div className="h-[60px]" />

              <section className="h-[120px] overflow-hidden border border-gray-300 p-[16px]">
                <h4 className="mb-[12px] text-[18px] font-bold text-gray-900">
                  購入前の確認
                </h4>
                <div className="text-[15px] font-medium leading-[23px] text-gray-700">
                  {product.prePurchaseCheck.map((line) => (
                    <div key={line}>{line}</div>
                  ))}
                </div>
              </section>

              <div className="h-[60px]" />

              <section className="h-[120px] overflow-hidden border border-gray-300 p-[16px]">
                <h4 className="mb-[12px] text-[18px] font-bold text-gray-900">
                  配送に関わる情報
                </h4>
                <div className="text-[15px] font-medium leading-[23px] text-gray-700">
                  {product.deliveryInfo.map((line) => (
                    <div key={line}>{line}</div>
                  ))}
                </div>
              </section>

              <div className="h-[60px]" />

              <button
                className="flex h-[50px] items-center justify-center rounded-md bg-black text-[18px] font-bold text-white"
                onClick={async () => {
                  const baseLog = createBaseLog();

                  await trackAction({
                    ...baseLog,
                    phase: "main",
                    page: "product",
                    type: "product_select",
                    meta: {},
                    payload: {
                      productId: product.id,
                      source: "detail_modal",
                    },
                  });

                  router.push(
                    `${nextPath}?set=${set}&trial=${trial}&productId=${product.id}`,
                  );
                }}
              >
                購入へ
              </button>

              <div className="h-[60px]" />
            </div>
          </div>
        </div>
      </dialog>
    </>
  );
}
