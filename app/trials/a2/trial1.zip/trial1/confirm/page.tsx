import Link from "next/link";
import { products6 } from "@/config/products";

function yen(n: number) {
  return new Intl.NumberFormat("ja-JP").format(n);
}

type Props = {
  searchParams?: Promise<{
    productId?: string;
    shipping?: string;
    options?: string | string[];
  }>;
};

function normalizeOptions(options?: string | string[]) {
  if (!options) return [];
  return Array.isArray(options) ? options : [options];
}

function getShippingInfo(shipping?: string) {
  switch (shipping) {
    case "express":
      return { label: "お急ぎ便", priceYen: 800 };
    case "scheduled":
      return { label: "日時指定便", priceYen: 700 };
    case "standard":
      return { label: "通常配送", priceYen: 500 };
    default:
      return { label: "未選択", priceYen: 0 };
  }
}

function getOptionInfo(option: string) {
  switch (option) {
    case "insurance":
      return { label: "配送補償オプション", priceYen: 300 };
    case "gift":
      return { label: "ギフト包装", priceYen: 200 };
    default:
      return { label: option, priceYen: 0 };
  }
}

export default async function ConfirmPageA2Trial1({ searchParams }: Props) {
  const sp = await searchParams;
  const productId = sp?.productId;
  const shipping = sp?.shipping;
  const optionKeys = normalizeOptions(sp?.options);

  const selectedProduct =
    products6.find((product) => product.id === productId) ?? products6[0];

  const shippingInfo = getShippingInfo(shipping);
  const selectedOptions = optionKeys.map(getOptionInfo);
  const optionTotal = selectedOptions.reduce(
    (sum, option) => sum + option.priceYen,
    0,
  );
  const total = selectedProduct.priceYen + shippingInfo.priceYen + optionTotal;

  const backParams = new URLSearchParams();
  backParams.set("productId", selectedProduct.id);
  if (shipping) backParams.set("shipping", shipping);
  optionKeys.forEach((option) => backParams.append("options", option));

  const completeParams = new URLSearchParams();
  completeParams.set("productId", selectedProduct.id);
  if (shipping) completeParams.set("shipping", shipping);
  optionKeys.forEach((option) => completeParams.append("options", option));

  return (
    <main className="h-screen overflow-hidden bg-gray-50 px-8 py-8">
      <div className="mx-auto flex h-full max-w-6xl flex-col">
        <div className="mb-6 rounded-lg border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800">
          <span className="font-semibold">購入条件：</span>
          「ミネラルウォーター 500ml×24」を1つ選んで購入してください
        </div>

        <header className="mb-5 shrink-0">
          <h1 className="text-xl font-bold text-gray-900">最終確認</h1>
        </header>

        <div className="grid flex-1 grid-rows-[152px_260px_176px_120px_88px] gap-6">
          {/* 上部：商品情報 */}
          <section className="rounded-xl border border-gray-200 bg-white px-6 py-6 shadow-sm">
            <div className="grid h-full grid-cols-[120px_1fr_auto] items-center gap-6">
              <div className="flex h-24 w-[120px] items-center justify-center rounded-lg bg-gray-100 text-xs text-gray-400">
                画像
              </div>

              <div className="min-w-0">
                <div className="truncate text-lg font-medium text-gray-800">
                  {selectedProduct.name}
                </div>
                <div className="mt-3 text-base text-gray-600">
                  商品価格：¥{yen(selectedProduct.priceYen)}
                </div>
                <div className="mt-2 text-sm text-gray-400">ご選択中の商品</div>
              </div>

              <div className="text-sm text-gray-400">注文商品</div>
            </div>
          </section>

          {/* 中段：配送方法 / 追加オプション */}
          <section className="grid h-full grid-cols-2 gap-5">
            <article className="rounded-xl border border-gray-100 bg-white p-4 shadow-sm">
              <h2 className="mb-4 text-sm font-medium text-gray-500">
                配送方法
              </h2>

              <div className="rounded-md border border-gray-100 bg-gray-50 px-4 py-3">
                <div className="text-sm font-medium text-gray-700">
                  {shippingInfo.label}
                </div>
                <div className="mt-1 text-sm text-gray-500">
                  {shippingInfo.priceYen > 0
                    ? `¥${yen(shippingInfo.priceYen)}`
                    : "選択されていません"}
                </div>
              </div>
            </article>

            <article className="rounded-xl border border-gray-100 bg-white p-4 shadow-sm">
              <h2 className="mb-4 text-sm font-medium text-gray-500">
                追加オプション
              </h2>

              <div className="space-y-2">
                {selectedOptions.length > 0 ? (
                  selectedOptions.map((option) => (
                    <div
                      key={option.label}
                      className="rounded-md border border-gray-100 bg-gray-50 px-4 py-3"
                    >
                      <div className="text-sm font-medium text-gray-700">
                        {option.label}
                      </div>
                      <div className="mt-1 text-sm text-gray-500">
                        +¥{yen(option.priceYen)}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="rounded-md border border-gray-100 bg-gray-50 px-4 py-3 text-sm text-gray-500">
                    選択されたオプションはありません
                  </div>
                )}
              </div>
            </article>
          </section>

          {/* 商品価格領域 */}
          <section className="rounded-xl border border-gray-200 bg-white px-6 py-5 shadow-sm">
            <div className="flex h-full flex-col justify-between">
              <div className="space-y-2 text-sm text-gray-900">
                <div className="flex items-center justify-between">
                  <span>商品価格</span>
                  <span>¥{yen(selectedProduct.priceYen)}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span>送料</span>
                  <span>¥{yen(shippingInfo.priceYen)}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span>オプション料金</span>
                  <span>¥{yen(optionTotal)}</span>
                </div>
              </div>

              <div className="flex items-center justify-between border-t border-gray-200 pt-3 text-sm">
                <span className="font-semibold text-gray-900">最終金額</span>
                <span className="text-2xl font-bold text-black">
                  ¥{yen(total)}
                </span>
              </div>
            </div>
          </section>

          {/* ボタン領域 */}
          <section className="rounded-xl border border-gray-200 bg-white px-6 py-5 shadow-sm">
            <div className="flex h-full flex-col gap-3">
              <Link
                href={`/trials/a2/trial1/complete?${completeParams.toString()}`}
                className="flex h-12 w-full items-center justify-center rounded-md bg-black px-5 text-sm font-medium text-white"
              >
                購入を確定する
              </Link>

              <Link
                href={`/trials/a2/trial1/checkout?${backParams.toString()}`}
                className="flex h-12 w-full items-center justify-center rounded-md border border-gray-300 bg-white px-5 text-sm font-medium text-gray-700"
              >
                戻る
              </Link>
            </div>
          </section>

          {/* 注意事項 */}
          <section className="rounded-xl border border-gray-100 bg-gray-50 px-6 py-4">
            <h2 className="mb-2 text-sm font-medium text-gray-400">注意事項</h2>

            <div className="space-y-1 text-sm leading-5 text-gray-500">
              <p>
                購入確定後は、注文内容の変更やキャンセルができない場合があります。
              </p>
              <p>
                配送方法・追加オプション・最終金額を確認したうえで、購入を確定してください。
              </p>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}
