export type Trial1Product = {
  id: string;
  role: "budget_over" | "condition_ng" | "correct" | "dp_candidate";
  failReason: "budget" | "quantity_condition" | "specific_condition" | null;
  name: string;
  priceYen: number;
  description: string;
  specsAndNotes: string[];
  prePurchaseCheck: string[];
  deliveryInfo: string[];
  dpDisplay?: { label: string } | null;
};
export type ShippingMethod = {
  id: string;
  name: string;
  priceYen: number;
  shortDescription: string;
};
export type AddonOption = {
  id: string;
  name: string;
  priceYen: number;
  shortDescription: string;
};
export const trial1Data = {
  purchaseConditions: {
    budgetYen: 1200,
    quantityCondition: "500ml×24本であること",
    specificCondition: "ミネラルウォーターであること",
  },
  products: [
    {
      id: "a2-t1-p1",
      role: "budget_over",
      failReason: "budget",
      name: "ミネラルウォーター 500ml×24本 プレミアム",
      priceYen: 1380,
      description: "500ml×24本のミネラルウォーターです。条件は満たしますが予算を超える商品です。",
      specsAndNotes: [
        "内容量：500ml×24本", "種類：ミネラルウォーター", "硬度：中硬水"
      ],
      prePurchaseCheck: [
        "予算内に収まるか確認してから選択してください", "購入手続き画面で配送方法や金額を最終確認できます"
      ],
      deliveryInfo: [
        "配送方法は購入手続き画面で選択できます", "地域によりお届け日が異なる場合があります"
      ],
      dpDisplay: null,
    },
    {
      id: "a2-t1-p2",
      role: "condition_ng",
      failReason: "specific_condition",
      name: "天然水風 飲料水 500ml×24本",
      priceYen: 980,
      description: "500ml×24本の商品ですが、ミネラルウォーターではない飲料水です。",
      specsAndNotes: [
        "内容量：500ml×24本", "種類：飲料水", "硬度：記載なし"
      ],
      prePurchaseCheck: [
        "ミネラルウォーターかどうかを確認してから選択してください", "購入手続き画面で配送方法や金額を最終確認できます"
      ],
      deliveryInfo: [
        "配送方法は購入手続き画面で選択できます", "地域によりお届け日が異なる場合があります"
      ],
      dpDisplay: null,
    },
    {
      id: "a2-t1-p3",
      role: "correct",
      failReason: null,
      name: "ミネラルウォーター 500ml×24本 ベーシック",
      priceYen: 880,
      description: "条件を満たす中で最も安いミネラルウォーターです。",
      specsAndNotes: [
        "内容量：500ml×24本", "種類：ミネラルウォーター", "硬度：軟水"
      ],
      prePurchaseCheck: [
        "条件に合う商品か確認してから選択してください", "購入手続き画面で配送方法や金額を最終確認できます"
      ],
      deliveryInfo: [
        "配送方法は購入手続き画面で選択できます", "地域によりお届け日が異なる場合があります"
      ],
      dpDisplay: null,
    },
    {
      id: "a2-t1-p4",
      role: "dp_candidate",
      failReason: null,
      name: "ミネラルウォーター 500ml×24本 まろやか",
      priceYen: 960,
      description: "条件は満たしますが、正解商品よりやや高いミネラルウォーターです。",
      specsAndNotes: [
        "内容量：500ml×24本", "種類：ミネラルウォーター", "硬度：軟水"
      ],
      prePurchaseCheck: [
        "条件に合う商品か確認してから選択してください", "購入手続き画面で配送方法や金額を最終確認できます"
      ],
      deliveryInfo: [
        "配送方法は購入手続き画面で選択できます", "地域によりお届け日が異なる場合があります"
      ],
      dpDisplay: null,
    },
  ] satisfies Trial1Product[],
  shippingMethods: [
    { id: "standard", name: "通常配送", priceYen: 0, shortDescription: "3〜5日でお届け" },
    { id: "express", name: "お急ぎ便", priceYen: 300, shortDescription: "最短で翌日にお届け" },
    { id: "scheduled", name: "日時指定便", priceYen: 200, shortDescription: "受け取り日時を指定できます" },
  ] satisfies ShippingMethod[],
  options: [
    { id: "insurance", name: "配送補償オプション", priceYen: 150, shortDescription: "破損・紛失時の補償を追加します" },
    { id: "gift", name: "ギフト包装", priceYen: 100, shortDescription: "プレゼント用に包装します" },
  ] satisfies AddonOption[],
};

export function getProductById(productId?: string) {
  return trial1Data.products.find((product) => product.id === productId) ?? trial1Data.products[0];
}

export function getShippingById(shippingId?: string) {
  return trial1Data.shippingMethods.find((method) => method.id === shippingId) ?? null;
}

export function getOptionsByIds(optionIds: string[]) {
  return trial1Data.options.filter((option) => optionIds.includes(option.id));
}

export default trial1Data;
