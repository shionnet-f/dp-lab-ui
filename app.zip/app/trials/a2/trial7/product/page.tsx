"use client";

import { useEffect, useRef } from "react";
import { useSearchParams } from "next/navigation";
import { ProductCard } from "@/app/trials/_components/a2TrialComponents/ProductCard";
import { TrialPageHeader } from "@/app/trials/_components/TrialPageHeader";
import { getTrialPath } from "@/app/trials/_lib/path";
import { trackAction } from "@/app/actions/track";
import trial7Data from "../data";

const checkoutPath = getTrialPath("a2", "trial7", "checkout");

type RankingAwardDisplay = {
  rankingLabel?: string;
  awardLabel?: string;
};

function RankingAwardBadge({
  dpDisplay,
}: {
  dpDisplay: RankingAwardDisplay;
}) {
  return (
    <div className="flex h-full w-full min-w-0 flex-col justify-center overflow-hidden border border-orange-400 bg-orange-100 px-3 text-[14px] font-semibold leading-[22px] text-orange-700">
      {dpDisplay.rankingLabel ? (
        <p className="truncate">{dpDisplay.rankingLabel}</p>
      ) : null}

      {dpDisplay.awardLabel ? (
        <p className="truncate">{dpDisplay.awardLabel}</p>
      ) : null}
    </div>
  );
}

export default function ProductPageA2Trial7() {
  const searchParams = useSearchParams();
  const set = searchParams.get("set");

  const didTrack = useRef(false);

  useEffect(() => {
    if (didTrack.current) return;
    didTrack.current = true;

    void trackAction({
      page: "product",
      type: "page_view",
      meta: {},
      payload: {},
    });
  }, []);

  if (!set) {
    return (
      <main className="flex h-screen items-center justify-center bg-gray-50">
        <div className="rounded-xl border border-red-200 bg-white p-6 text-sm text-red-700">
          URLに set がありません。
        </div>
      </main>
    );
  }

  const products = trial7Data.products;

  return (
    <main className="h-[1080px] w-[1920px] overflow-hidden bg-gray-50">
      <div className="h-full w-full">
        <TrialPageHeader
          purchaseConditions={trial7Data.purchaseConditions}
          title="商品一覧"
        />

        {/* 商品カード領域：160px * 4 + 60px * 3 = 820px */}
        <section className="mx-auto flex h-[820px] w-[1160px] flex-col gap-[60px] overflow-hidden">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              set={set}
              checkoutPath={checkoutPath}
              dpArea={
                product.dpDisplay ? (
                  <RankingAwardBadge dpDisplay={product.dpDisplay} />
                ) : undefined
              }
            />
          ))}
        </section>

        {/* 95pxの空間 */}
        <div className="h-[95px]" />
      </div>
    </main>
  );
}