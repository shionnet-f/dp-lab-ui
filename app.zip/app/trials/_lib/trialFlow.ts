import { getTrialPath } from "./path";
import { trialOrder, type TrialSetId } from "./trialOrder";

type GetNextTrialPathArgs = {
  setId: TrialSetId;
  setIndex: string;
  trialIndex: string;
};

export function getCurrentTrialFolderName({
  setId,
  trialIndex,
}: {
  setId: TrialSetId;
  trialIndex: string;
}) {
  const index = Number(trialIndex) - 1;

  if (Number.isNaN(index) || index < 0) {
    return null;
  }

  return trialOrder[setId][index] ?? null;
}

export function getNextTrialOrFixationPath({
  setId,
  setIndex,
  trialIndex,
}: GetNextTrialPathArgs) {
  const currentIndex = Number(trialIndex);

  if (Number.isNaN(currentIndex)) {
    return `/experiment/fixation?set=${setIndex}&position=after`;
  }

  const nextIndex = currentIndex + 1;
  const nextTrialFolderName = trialOrder[setId][nextIndex - 1];

  if (!nextTrialFolderName) {
    return `/experiment/fixation?set=${setIndex}&position=after`;
  }

  return `${getTrialPath(setId, nextTrialFolderName, "start")}?set=${setIndex}&trial=${nextIndex}`;
}
